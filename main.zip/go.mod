module s

go 1.27.3

require (
	github.com/bwmarrin/discordgo v0.29.0
	github.com/kbinani/screenshot v0.0.0-20250624051815-089614a94018
	golang.org/x/sys v0.50.0
)

require (
	github.com/gen2brain/shm v0.1.0 // indirect
	github.com/godbus/dbus/v5 v5.1.0 // indirect
	github.com/gorilla/websocket v1.4.2 // indirect
	github.com/jezek/xgb v1.1.1 // indirect
	github.com/lxn/win v0.0.0-20210218163916-a377121e959e // indirect
	golang.org/x/crypto v0.0.0-20210421170649-83a5a9bb288b // indirect
)
